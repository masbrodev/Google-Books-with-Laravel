## Installation

- `git clone https://github.com/AbdullahGhanem/books.git`
- `cd books`
- `composer install`
- create `.env` from `.env.example` file and set your database connection details
- `php artisan migrate`
